import time
import re
import datetime
import random
import cx_Oracle
con=cx_Oracle.connect('yoge/12@xE')
cur=con.cursor()
#cust_name
#cust_add1,cust_ph,cust_father,pan_num,ad_num,exis0t,dob,op2,op1,mail,bal,ac,pas
def customer():
    print("                             BANK OF WAKANDA             ")
    print("Select options")
    print("1.FUND TRANSFER\n2.NEARBY ATMs\n3.MEMBERSHIP\n4.Deposit\n5.Withdraw\n6.Loan\n7.Report generation\n8.Nearby ATM\n")
    option=int(input())
    if(option == 1):
        print("FUND TRANSFER")
        account_number1=int(input("Your id id:"))
        l=cur.execute("select balance from cus where accountn = %d"%account_number1)
        if(len(l.fetchall())):
           pass
                                                                                                                                           #goto
        else:
           print("invalid account number")
            
        account_number=int(input("Receiver id:"))
        m=cur.execute("select balance from cus where accountn = %d"%account_number1)
        if(len(m.fetchall())):
           pass
        else:
           print("invalid accountnumber")
        amount_to_send=int(input("Amount   :"))
        cur.execute("select balance from cus where accountn = %d"%account_number1)
        temp_amount=cur.fetchone()
        print(temp_amount)
        
        if (temp_amount[0] >= amount_to_send):
            s=cur.execute("select balance from cus where accountn = %d"%account_number1)
            r=cur.execute("select balance from cus where accountn = %d"%account_number)
            print(s.fetchone())
            print(r)
            print("Transaction going on....")
            time.sleep(2)
            print("Transaction succesfull")
            cur.execute("select balance from cus where account_no = %d"%account_number1)
            a=cur.fetchone();
            aa=a[0]-amount_to_send
            cur.execute ("update cus set balance=%d where account_no = %d"%(aa,account_number1))
            cur.execute("select balance from cus where account_no = %d"%account_number)
            b=cur.fetchone();
            bb=b[0]+amount_to_send
            cur.execute ("update cus set balance=%d where account_no = %d"%(bb,account_number))
            con.commit()
        else:
            print("Amount exceeds the balance")
    elif (option==4):
         acc=int(input("enter the account number"))
         dep=int(input("enter the amount to deposit"))
         cur.execute("select balance from cus where account_no = %d"%acc)
         dep1=cur.fetchone();
         dep2=dep1[0]+dep
         cur.execute ("update cus set balance=%d where account_no = %d"%(dep2,acc))
         con.commit()
         
         
    elif (option==5):
         acc1=int(input("enter the account number"))
         de=int(input("enter the amount to withdraw"))
         cur.execute("select balance from cus where account_no = %d"%acc1)
         de1=cur.fetchone();
         if((de1[0]-de)>2000):
             de2=de1[0]-de
             cur.execute ("update cus set balance=%d where account_no = %d"%(de2,acc1))
             con.commit()
         else:
             print("unable to withdraw bcoz of the minimum balance")
    elif (option==6):
         loan()
    elif (option==7):
         cur.execute("select * from cus w")
        #pass
         w=cur.fetchall()
         print(w)
    elif(option==8):
         ci=input("Enter the city name")
         cur.execute("select name from loc group by '%s'"%ci)
         for i in cur.fetchall():
             print (i)
     
     
    
def manager():
    print("1.add new customer\n2.Remove customer")
    choice=input("choice")
    if (choice=='1'):
        signup()
    elif(choice=='2'):
        remove()
    elif(choice=='3'):
        an=int(input("enter the account number"))
        cur.execute("select * from cus where accountn = %d"%(an))
        #pass
        for i in cur.fetchall():
            print(i)
def signup():
        global cust_name
        #cust_add1,cust_ph,cust_father,pan_num,ad_num,exis0t,dob,op2,op1,mail,bal,ac,pas
        
        def add():
            print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ADD NEW CUSTOMER~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
            cust_name=input("Enter custome name:")#name
            name(cust_name)
            cust_add1=input("Enter address :")#address
            phone(cust_name)#phone
            cust_father=input("Enter father's name:")#father's name
            name1(cust_father)
            email(cust_name)
            pan(cust_name)
            aadhar(cust_name)
            dob(cust_name)
            mb(cust_name)
            acn(cust_name)
            exist=input("Enter wthether you have existing bank accounts:")
            op1=input("would like to have \n1.credit card \n2.debit card\n3.both\n4.none?")
            print("Your Choice for",op1,"has been Noted!!")
            op2=input("Would you like to avail Net banking?\n 1.yes \n 2.No")
            if(op2=='1'):
                eb()
            else:
                eb1()
           #cur.execute("insert into customer()")
        def name(cust_name):
            cn_len=len(cust_name)
            sp_count=0
            for i in cust_name:
                if i==' ':
                 sp_count+=1
            if(cn_len<25 and sp_count!=0):
             cur.execute("insert into cus (name) values('%s')"%cust_name)
             con.commit()
             pass
            else:
                print("Invalid name")
                cust_name=input("Enter the correct name")
                name(cust_name)
        def name1(cust_father):
            cn_len=len(cust_father)
            sp_count=0
            for i in cust_name:
                if i==' ':
                 sp_count+=1
            if(cn_len<25 and sp_count!=0):
             cur.execute("update cus set fh='%s' where name='%s'"%(cust_father,cust_name))
             con.commit()
             pass
            else:
                print("Invalid name")
                cust_name=input("Enter the correct name")
                name(cust_father)      
        def phone(cust_name):
            #print(cust_name)
            cust_ph=input("Enter contact number:")
            cust_ph1=int(cust_ph)
            if(len(cust_ph)==10):
                cur.execute("update cus set phone=%d where name='%s'"%(cust_ph1,cust_name))
                con.commit()
                print("Contact Number Added!!")
            else:
                print("Invalid!!")
                phone()
        def email(cust_name):
            mail=input("Enter email address:")
            match=re.match('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-0-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$',mail)
            if match==None:
                print("Invalid mail address!!!")
                email()
        def pan(cust_name):
                 pan_num=int(input("Enter pan number:"))
                 if(len(pan_num)==10 ):#and pan_num[0:5].isalpha() and pan_num[5:8] and pan_num[9].isalpha()):
                     pass
                 else:
                    print("Incorrect!!Check your PAN number");
                    pan()
        def aadhar(cust_name):
                ad_num=input("Enter aadhar number:")
                ad_len=len(ad_num)
                if(ad_len==12):
                    pass
                else:
                    print("Incorrect!!Check your AADHAR number")
                    aadhar()
        def dob(cust_name):
            dob=input("Enter Dte of Birth in the Format MM-DD-YYYY:");
            if(len(dob)==13):
               pass
            else:
               print("Invalid")
               dob()
        def mb(cust_name):
            bal=int(input("Enter amount to depsosit"))
            if(bal>=1000):
               pass
            else:
               print("enter more than 1000")
               mb()
        def acn(cust_name):
            ac=random.randint(1,10334566098712345)
            
        def eb(cust_name):
           
            pas=input("Enter password")
        
            cur.execute("insert into cus values('%s','%s',%d,'%s',%d,%d,'%s','%s','%s','%s','%s',%d,%d,'%s')"%(cust_name,cust_add1,cust_ph,cust_father,pan_num,ad_num,exis0t,dob,op2,op1,mail,bal,ac,pas))
        def eb1(cust_name):
           
            cur.execute("insert into cus values('%s','%s',%d,'%s',%d,%d,'%s','%s','%s','%s','%s',%d,%d,'%s')"%(cust_name,cust_add1,cust_ph,cust_father,pan_num,ad_num,exis0t,dob,op2,op1,mail,bal,ac))
        add()
def remove():
    accc1=int(input("enter the account number"))
    log1= cur.execute("SELECT * from cus WHERE account_no ='%d'"%(accc1))

    if (len(log1.fetchall())):
        cur.execute("delete from cus where account_no = %d"%accc1)
        con.commit()
    else:
        print("invalid account number")
        remove()
def loan():
    acc12=int(input("enter the account number"))
    cur.execute("select balance from cus where account_no = %d"%(acc12))
    bal=cur.fetchone()
    if(bal[0]>5000):
        duration = int(input("Enter duration in number of months : "))
        print("Loan Successfully granted")
    else:
        print("Loan not granted")

def login()   : 
    U= input("User: ")
    P=input("Password: ")
    log= cur.execute("SELECT * from cus WHERE name ='%s' and password='%s'"%(U,P))

    if (len(log.fetchall())):
        print(log.fetchall)
        #print("Welcome",U)
        if(U=='ADMIN'):
            print("Manager Login")
            print("Welcome",U)
            manager()
        else:
            print("Customer Login")
            print("Welcome",U)
            customer()

    else:
        print("Login Failed")
    #print("Login Page")
login()
