import webbrowser

webbrowser.open('https://www.google.com/maps/search/atms+near+skcet/@10.9429934,76.9440049,15z')#ATMs near SKCET
webbrowser.open('https://www.google.com/maps/search/atms+near+chennai+central/@13.0845153,80.2630116,15z/data=!3m1!4b1')#ATM near Chennai central
webbrowser.open('https://www.google.com/maps/search/atm+near+trichy+central+bus+stand/@10.7980284,78.6784279,15.75z')#ATM near Trichy junction
